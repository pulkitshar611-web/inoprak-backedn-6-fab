-- Add missing fields to companies table
  