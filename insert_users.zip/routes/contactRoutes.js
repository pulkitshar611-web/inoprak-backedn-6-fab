// =====================================================
// Master Contact routes (single source of truth: contacts table)
// Same logic as /leads/contacts; use /contacts for Contact tab and Deal "link contact" picker.
// =====================================================

const express = require('express')
const router = express.Router()
const leadController = require('../controllers/leadController')
const { verifyToken } = require('../middleware/auth')

router.get('/', verifyToken, leadController.getAllContacts)
router.get('/:id', verifyToken, leadController.getContactById)
router.post('/', verifyToken, leadController.createContact)
router.put('/:id', verifyToken, leadController.updateContact)
router.delete('/:id', verifyToken, leadController.deleteContact)

module.exports = router
